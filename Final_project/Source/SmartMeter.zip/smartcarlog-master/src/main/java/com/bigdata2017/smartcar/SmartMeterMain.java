package com.bigdata2017.smartcar;

import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SmartMeterMain {

	public static void main(String[] args) {
		SmartMeter sm =  new SmartMeter();
		sm.show();
	}
}