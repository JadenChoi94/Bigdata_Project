package com.bigdata2017.smartcar;

import java.util.Random;

public class SmartMeterReal
{
	private  String smartmeterno;
	private  int customno; 
	private  double kw;
	private  String macaddr;
	private  Random r =  new Random();
	public SmartMeterReal(){}
	
	public SmartMeterReal(String smartmeterno, int customno, double kw, String macaddr) {
		super();
		this.smartmeterno = smartmeterno;
		this.customno = customno;
		this.kw = kw;
		this.macaddr = macaddr;
	}
	public String getSmartmeterno()
	{
		return smartmeterno;
	}
	public void setSmartmeterno(String smartmeterno) {
		this.smartmeterno = smartmeterno;
	}
	public int getCustomno() {
		return customno;
	}
	public void setCustomno(int customno) {
		this.customno = customno;
	}
	public double getKw() {
		// 현재 월 6,7,8 
		return  Math.abs( r.nextDouble()%1.28+ 0.4 * 0.15);
	}
	public void setKw(double kw) {
		this.kw = kw;
	}
	public String getMacaddr() {
		return macaddr;
	}
	public void setMacaddr(String macaddr) {
		this.macaddr = macaddr;
	}

	

}
