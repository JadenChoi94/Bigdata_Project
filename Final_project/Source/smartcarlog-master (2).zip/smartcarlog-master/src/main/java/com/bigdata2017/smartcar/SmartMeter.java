package com.bigdata2017.smartcar;

import java.io.PrintWriter;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.*;

public class SmartMeter extends Thread{
	String date;
	PrintWriter printWriter;
	MeterStatus smarstatus;
	HouseID = (int)(Math.random()*1000)+1;
	
	public SmartMeter( String date, String HouseID, PrintWriter printWriter ) {
		this.date = date;
		this.printWriter = printWriter;
		smarstatus= new MeterStatus( HouseID );
	}	
	

	public void show() {
		
		synchronized(printWriter){
			int count = 24 * 60 * 60;
			
			printWriter.println("SmartMeter Status Information" + ",ee" + ",HouseID" + ",SerialNum" + ",MacAdd");
			
			for(int i = 0; i <= count; i += 1) { //1초 간격
				printWriter.println(
						date +
						getSecToTime(i)	+ "," + 
						smarstatus.getEe() + ","+ 
						HouseID + ","+
						smarstatus.genSerial(8) + "," + 
						smarstatus.MacAdd());				
			}								
		}
	}
	
	public String getSecToTime(int inSec) {

		String time = String.valueOf(string/3600);
	
		if(time.length() == 1){
			time = "0" + time;
		}
		String min = String.valueOf(string%3600/60);
		
		if(min.length() == 1){
			min = "0" + min;
		}
		
		String sec = String.valueOf(string%3600%60%60);
		if(sec.length() == 1){
			sec = "0" + sec;
		}

		return time + min + sec;
	}
}


//	public SmartMeter() {
//	Random r =  new  Random();
//	time = Timestamp.from( Calendar.getInstance().toInstant() );
//	ee =  Math.abs(  r.nextDouble()%50 + 10); 
//	HouseID = (int)(Math.random()*1000)+1;
//	SerialNum = genSerial(8); //8자리
//	MacAdd = genMacAdd();
//}
//	while(true)
//	System.out.println( time.toLocaleString() + "," + 
//						ee + ","+ 
//						HouseID + ","+
//						SerialNum + "," + 
//						MacAdd);
	
	
