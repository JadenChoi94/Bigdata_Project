package com.bigdata2017.smartcar;

import java.sql.Timestamp;
import java.util.Random;

public class MeterStatus {
	private Timestamp time;
	private double ee;  
	private String HouseID;
	private String SerialNum;
	private String MacAdd;
	
	public MeterStatus( String HouseID ){
		this.HouseID = HouseID;
	}
	
	
	Random r =  new  Random();
	 
	SerialNum = genSerial(8); //8자리
	MacAdd = genMacAdd();

	public static int randomRange(int n1, int n2) {  
		return (int)((Math.random() * (n2 - n1 + 1)) + n1);
	}
//	public Timestamp getTime() {
//		return time;
//	}
//	public void setTime(Timestamp time) {
//		this.time = time;
//	}
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public double getEe() {
		ee =  Math.abs( r.nextDouble()%50 + 10);
		return ee;
	}
	public void setEe(double ee) {
		this.ee = ee;
	}

	public String getGenSerial(int length){
        char[] charaters = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','0','1','2','3','4','5','6','7','8','9'};
        StringBuffer sb = new StringBuffer();
        Random rn = new Random();
        
        for( int i = 0 ; i < length ; i++ ){
            sb.append( charaters[ rn.nextInt( charaters.length ) ] );
        }
        return sb.toString();
    }

	public String genMacAdd(){
	    Random rand = new Random();
	    byte[] macAddr = new byte[6];
	    rand.nextBytes(macAddr);

	    macAddr[0] = (byte)(macAddr[0] & (byte)254);  

	    StringBuilder sb = new StringBuilder(18);
	    for(byte b : macAddr){
	        if(sb.length() > 0)
	            sb.append(":");
	        sb.append(String.format("%02x", b));
	    }

	    return sb.toString();
	}
	
		
	
}
