package com.bigdata2017.smartcar;

import java.util.Map;
import java.util.Random;

public class SmartMeterReal
{
	private  String smartmeterno;
	private  int customno; 
	private  double kw;
	private  String macaddr;
	private  Random r =  new Random();
	public SmartMeterReal(){}
	
	public SmartMeterReal(String smartmeterno, int customno, double kw, String macaddr) {
		super();
		this.smartmeterno = smartmeterno;
		this.customno = customno;
		this.kw = kw;
		this.macaddr = macaddr;
	}
	
	public String getSmartmeterno()
	{
		
		return smartmeterno;
	}
	public void setSmartmeterno(String smartmeterno) {
		this.smartmeterno = smartmeterno;
	}
	public int getCustomno() {
		return customno;
	}
	public void setCustomno(int customno) {
		this.customno = customno;
	}
	
	
	
	public double getKw() { //가중치 추가
		// 계절 월 6,7,8
		Random r = new Random();
		String month = "20191017".substring(4,6);
		
		double month2 	   = Integer.parseInt(month);
		double totaldevice = (double)((Math.random()%20 + 2) - 4)  /10;
		double familyno    = (double)((Math.random()%7 + 1) - 2) /10;
		
		
		month2 *=0.1; //  월평 가중치 !! 		
		
		return  Math.abs( r.nextDouble()% 1.28 + 0.4 ) * (month2 + totaldevice + familyno) ;
		
		
	}
	public void setKw(double kw) {
		this.kw = kw;
	}
	public String getMacaddr() {
		return this.genMacAdd();
	}
	public void setMacaddr(String macaddr) {
		this.macaddr = macaddr;
	}
	
	public String genMacAdd(){
	    Random rand = new Random();
	    byte[] macAddr = new byte[6];
	    rand.nextBytes(macAddr);

	    macAddr[0] = (byte)(macAddr[0] & (byte)254);  

	    StringBuilder sb = new StringBuilder(18);
	    for(byte b : macAddr){
	        if(sb.length() > 0)
	            sb.append(":");
	        sb.append(String.format("%02x", b));
	    }
	   
	    return sb.toString();
	}
	

	

}
