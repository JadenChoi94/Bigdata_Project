package com.bigdata2017.smartcar;

import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.Iterator;

public class test {

	public static void main(String[] args) {
		
		

		
//		HashSet<Integer> hs = new HashSet<Integer>();
//		hs.add((int)(Math.random()*(100-1+1)+1));
//		
//		Iterator<Integer> ir = null;
//		int rn = 0;
//		
//		while(hs.size() < 100){
//			hs.add((int)(Math.random()*(100-1+1)+1));
//			ir = hs.iterator();
//		}
//		while(ir.hasNext()){
//			rn = ir.next();
//			System.out.println(rn);
//		}
	}
}
