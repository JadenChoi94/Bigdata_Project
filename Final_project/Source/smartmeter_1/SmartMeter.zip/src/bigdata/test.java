package bigdata;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.io.*;
import java.lang.reflect.Array;
import java.io.*;
import java.util.*;
import java.util.Random;

	public class test {
	
		public static void main(String[] args) {	

			Random rand   = new Random();
			System.out.println ( ((10.16406573*rand.nextGaussian())+206)/720 );
			} 
}
		
	
