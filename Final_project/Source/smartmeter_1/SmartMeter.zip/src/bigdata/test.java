package bigdata;

import java.util.Random;

public class test {

	public static void main(String[] args) {
		int famCount = 0;
		Random rand   = new Random();
		int a[] = new int[100];
		
		for(int i=0; i<100; i++) 
		{
			a[i] = rand.nextInt(100)+1;
			for(int j=0; j<i; j++)
			{
				if(a[i] == a[j])
				{
					i--;
				}
			}				
		}
		for (int b=0; b<100; b++)
		{		    
			//1���϶� 
	        if(a[b] >=0 && a[b] <= 14) {
	        	famCount = 1;
	        }
	        //2���϶�
	        else if (a[b] > 14 && a[b] <= 42){
	        	famCount = 2;
	        }
	        //3���϶�
	        else if (a[b] > 42 && a[b] <= 66){
	        	famCount = 3;
	        }
	        //4�� �϶�
	        else if (a[b] > 66 && a[b] <= 90){
	        	famCount = 4;
	        }
	        //5�� �϶�
	        else if (a[b] > 90 && a[b] <= 96){
	        	famCount = 5;
	        }
	        //6�� �϶�
	        else if (a[b] == 97){
	        	famCount = 6;
	        }
	        //7�� �϶�
	        else if (a[b] == 98){
	        	famCount = 7;
	        }
	        //8�� �϶�
	        else if (a[b] == 99) {
	        	famCount = 8;
	        }
	        //9�� �϶�
	        else {
	        	famCount = 9;
	        }	 
		}
		System.out.println( famCount );
		}
	}
